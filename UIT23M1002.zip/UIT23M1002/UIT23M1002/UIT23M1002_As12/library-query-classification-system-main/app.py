import html
import pandas as pd
import streamlit as st
from nlp_core import LibrarySystem, preprocess, LOW_CONF
from data import CATEGORIES

st.set_page_config(page_title="Central Library · Smart Search", page_icon="📚", layout="wide",
                   initial_sidebar_state="collapsed")

COLORS = {"Computer Science & IT": "#2B4C7E", "Electrical & Electronics Engineering": "#B5651D",
          "Mechanical & Civil Engineering": "#5B6770", "Mathematics & Statistics": "#6A4C93",
          "Physics": "#1B6CA8", "Chemistry": "#2F8F6B", "Biology & Medicine": "#B23A48",
          "Agriculture & Environment": "#4F772D", "Economics & Business": "#B07D00",
          "Humanities & Social Sciences": "#7A3E3E"}
EXAMPLES = ["backend development", "impact of global warming on food production",
            "machine that learns from data", "how to invest money in shares",
            "why do objects fall under gravity", "treatment of infectious diseases"]

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,500;6..72,600&family=Figtree:wght@400;500;600;700&display=swap');
:root{--ink:#172033;--mut:#5F6B7C;--line:#DDE2EA;--paper:#F4F6F9;--card:#fff;--brass:#B8862B;}
html,body,[class*="css"],.stApp{font-family:'Figtree',system-ui,sans-serif;color:var(--ink);}
.stApp{background:var(--paper);}
header[data-testid="stHeader"],#MainMenu,footer,[data-testid="stToolbar"]{display:none!important;}
.block-container{max-width:1180px;padding:1.2rem 1.5rem 3rem;}
h1,h2,h3,.serif{font-family:'Newsreader',Georgia,serif;letter-spacing:-.01em;}
/* top bar */
.top{display:flex;align-items:center;gap:.8rem;padding:.2rem 0 1.4rem;border-bottom:1px solid var(--line);}
.logo{width:38px;height:38px;border-radius:10px;background:var(--ink);color:#fff;display:grid;place-items:center;font-size:20px;}
.top b{font-size:1.02rem}.top small{display:block;color:var(--mut);font-size:.8rem;margin-top:-2px}
/* hero */
.hero{padding:2.6rem 0 1rem;}
.hero h1{font-size:clamp(2rem,4.2vw,3.1rem);line-height:1.1;margin:0 0 .6rem;font-weight:600;max-width:15em;}
.hero p{color:var(--mut);font-size:1.05rem;margin:0 0 1.2rem;max-width:42em;}
/* search */
div[data-testid="stForm"]{border:0;padding:0;background:transparent;}
div[data-testid="stTextInput"] input{height:3.4rem;font-size:1.08rem;border-radius:14px;border:2px solid var(--ink);padding:0 1.1rem;background:#fff;}
div[data-testid="stTextInput"] input:focus{border-color:var(--brass);box-shadow:0 0 0 4px rgba(184,134,43,.18);}
div[data-testid="stFormSubmitButton"] button{height:3.4rem;border-radius:14px;background:var(--ink);color:#fff;border:0;font-weight:600;font-size:1rem;}
div[data-testid="stFormSubmitButton"] button:hover{background:#26334f;color:#fff;}
div[data-testid="stFormSubmitButton"] button:focus-visible,.stButton button:focus-visible{outline:3px solid var(--brass);outline-offset:2px;}
/* pills (chips / save) */
.stButton button{border-radius:999px;border:1px solid var(--line);background:#fff;color:var(--ink);font-size:.86rem;font-weight:500;padding:.25rem .9rem;min-height:2.1rem;transition:border-color .15s,background .15s;}
.stButton button:hover{border-color:var(--ink);background:#fff;color:var(--ink);}
.label{color:var(--mut);font-size:.84rem;margin:.9rem 0 .3rem;font-weight:500}
/* tabs */
button[data-baseweb="tab"]{font-weight:600;font-size:.98rem;}
div[data-baseweb="tab-highlight"]{background:var(--ink)!important;}
/* book card */
.book{display:flex;gap:1.1rem;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:1.05rem 1.15rem;}
.cover{flex:0 0 62px;height:88px;border-radius:4px 8px 8px 4px;background:var(--c);position:relative;display:grid;place-items:center;color:#fff;
 font-family:'Newsreader',Georgia,serif;font-weight:600;font-size:1.25rem;box-shadow:3px 3px 0 rgba(23,32,51,.14);}
.cover:before{content:"";position:absolute;left:7px;top:0;bottom:0;width:2px;background:rgba(255,255,255,.35);}
.meta{min-width:0;flex:1}
.t{font-family:'Newsreader',Georgia,serif;font-size:1.28rem;font-weight:600;line-height:1.2}
.a{color:var(--mut);font-size:.92rem;margin:.1rem 0 .55rem}
.tag{display:inline-block;background:#EEF1F6;color:#3B475C;border-radius:6px;padding:.12rem .5rem;font-size:.78rem;margin:0 .3rem .3rem 0}
.rel{display:flex;align-items:center;gap:.6rem;margin-top:.35rem}
.bar{flex:0 0 120px;height:6px;border-radius:9px;background:#E6EAF1;overflow:hidden}.bar i{display:block;height:100%;background:var(--brass)}
.rel small{color:var(--mut);font-size:.8rem}
/* side panel */
.panel{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:1.15rem 1.2rem;margin-bottom:1rem}
.panel h3{font-size:1.1rem;margin:0 0 .7rem}
.subject{display:flex;align-items:center;gap:.6rem;font-family:'Newsreader',Georgia,serif;font-size:1.3rem;font-weight:600;line-height:1.2}
.dot{width:14px;height:14px;border-radius:4px;background:var(--c);flex:0 0 14px}
.conf{color:var(--mut);font-size:.88rem;margin:.25rem 0 .8rem}
.pr{display:grid;grid-template-columns:1fr 38px;gap:.5rem;align-items:center;font-size:.85rem;margin:.35rem 0}
.pr .n{margin-bottom:3px}.pr .b{height:6px;background:#E6EAF1;border-radius:9px;overflow:hidden}.pr .b i{display:block;height:100%;background:var(--c)}.pr .v{text-align:right;color:var(--mut)}
.note{background:#FFF6E0;border:1px solid #F0DDAA;border-radius:12px;padding:.7rem .9rem;font-size:.9rem;margin:.2rem 0 1rem}
.empty{background:var(--card);border:1px dashed #C4CBD8;border-radius:16px;padding:2rem;text-align:center;color:var(--mut)}
.empty b{display:block;color:var(--ink);font-size:1.1rem;margin-bottom:.3rem}
.stat{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:1rem 1.2rem}
.stat .v{font-family:'Newsreader',Georgia,serif;font-size:2rem;font-weight:600}.stat .l{color:var(--mut);font-size:.88rem}
.sec{font-size:1.35rem;font-weight:600;margin:1.2rem 0 .6rem}
@media (max-width:760px){.cover{flex-basis:48px;height:70px}.bar{flex-basis:80px}.hero{padding-top:1.4rem}}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>""", unsafe_allow_html=True)

@st.cache_resource(show_spinner="Loading the library catalogue…")
def load():
    s = LibrarySystem(); return s, s.evaluate()
system, EVAL = load()

ss = st.session_state
ss.setdefault("q", ""); ss.setdefault("saved", {}); ss.setdefault("history", [])
esc = html.escape
def set_q(v): ss["q"] = v
def toggle(bid, rec):
    ss.saved.pop(bid) if bid in ss.saved else ss.saved.update({bid: rec})

def initials(t):
    w = [x for x in t.replace(":", " ").split() if x[0].isalpha() and x.lower() not in ("the", "a", "an", "of", "to", "and", "in")]
    return esc("".join(x[0] for x in w[:2]).upper() or "B")

def card(rec, pct, prefix, i):
    title, author, cat, desc = rec
    bid = f"{title}|{author}"
    tags = "".join(f'<span class="tag">{esc(w)}</span>' for w in list(dict.fromkeys(x for x in desc.split() if len(x) > 3))[:5])
    rel = f'<div class="rel"><div class="bar"><i style="width:{pct}%"></i></div><small>{pct}% match</small></div>' if pct is not None else ""
    c1, c2 = st.columns([6, 1.25], vertical_alignment="center")
    c1.markdown(f'<div class="book"><div class="cover" style="--c:{COLORS.get(cat, "#444")}">{initials(title)}</div>'
                f'<div class="meta"><div class="t">{esc(title)}</div><div class="a">{esc(author)} · {esc(cat)}</div>{tags}{rel}</div></div>',
                unsafe_allow_html=True)
    c2.button("Saved ✓" if bid in ss.saved else "Save", key=f"{prefix}{i}", on_click=toggle, args=(bid, rec))

def pct_of(results):
    top = max((s for _, s in results), default=0)
    return [round(100 * s / top) if top > 0 else 0 for _, s in results]

# ---------------- header & hero ----------------
st.markdown('<div class="top"><div class="logo">📚</div><div><b>Central Library</b>'
            '<small>Sanjivani College of Engineering, Kopargaon</small></div></div>', unsafe_allow_html=True)
st.markdown('<div class="hero"><h1>Find the right book, even when you don’t know its name.</h1>'
            '<p>Describe a topic in your own words. We work out the subject and rank the most relevant books on our shelves.</p></div>',
            unsafe_allow_html=True)

with st.form("search", border=False):
    a, b = st.columns([6, 1], vertical_alignment="bottom")
    a.text_input("Search the catalogue", key="q", label_visibility="collapsed",
                 placeholder="Try “backend development” or “effects of climate change on agriculture”")
    submitted = b.form_submit_button("Search")

with st.expander("Search options"):
    o1, o2 = st.columns(2)
    model = o1.radio("Classifier", ["SVM", "Naive Bayes"], horizontal=True)
    top_k = o2.slider("Results to show", 3, 10, 5)

query = ss.q.strip()
if query and (not ss.history or ss.history[0] != query):
    ss.history = ([query] + [h for h in ss.history if h != query])[:5]

st.markdown('<div class="label">Popular searches</div>', unsafe_allow_html=True)
cols = st.columns(len(EXAMPLES))
for c, e in zip(cols, EXAMPLES):
    c.button(e, key=f"ex_{e}", on_click=set_q, args=(e,))
if len(ss.history) > 0:
    st.markdown('<div class="label">Recent</div>', unsafe_allow_html=True)
    hc = st.columns(5)
    for c, h in zip(hc, ss.history):
        c.button(h, key=f"h_{h}", on_click=set_q, args=(h,))

n_saved = len(ss.saved)
tab_s, tab_b, tab_l, tab_m = st.tabs(["Search results", "Browse by subject", f"Reading list ({n_saved})", "How it works"])

# ---------------- search ----------------
with tab_s:
    if not query:
        st.markdown('<div class="empty"><b>Start with a topic</b>Type a question or pick a popular search above. '
                    'You can use everyday words, the catalogue doesn’t need the exact title.</div>', unsafe_allow_html=True)
    else:
        cat, probs, results = system.search(query, model, top_k)
        if cat is None or not results:
            st.markdown('<div class="empty"><b>No match for that search</b>We couldn’t recognise any words in it. '
                        'Try a subject name like “thermodynamics” or describe what you want to learn.</div>', unsafe_allow_html=True)
        else:
            conf = probs[cat]; ranked = sorted(probs, key=probs.get, reverse=True)
            left, right = st.columns([7, 3.6], gap="large")
            with left:
                st.markdown(f'<div class="sec serif">{len(results)} books for “{esc(query)}”</div>', unsafe_allow_html=True)
                if conf < LOW_CONF:
                    st.markdown(f'<div class="note">We’re not fully sure about this search. It could also be '
                                f'<b>{esc(ranked[1])}</b>. Add a few more words to narrow it down.</div>', unsafe_allow_html=True)
                for i, ((rec), p) in enumerate(zip(results, pct_of(results))):
                    card(rec[0], p, "r", i)
                if conf < LOW_CONF:
                    alt = system.rank_in(ranked[1], query, 3)
                    st.markdown(f'<div class="sec serif">Also in {esc(ranked[1])}</div>', unsafe_allow_html=True)
                    for i, (rec, p) in enumerate(zip(alt, pct_of(alt))):
                        card(rec[0], p, "a", i)
            with right:
                bars = "".join(f'<div class="pr" style="--c:{COLORS.get(c, "#444")}"><div><div class="n">{esc(c)}</div>'
                               f'<div class="b"><i style="width:{probs[c]*100:.0f}%"></i></div></div><div class="v">{probs[c]:.0%}</div></div>'
                               for c in ranked[:4])
                toks = "".join(f'<span class="tag">{esc(t)}</span>' for t in dict.fromkeys(preprocess(query, expand=True)))
                st.markdown(f'<div class="panel"><h3>Subject we found</h3>'
                            f'<div class="subject" style="--c:{COLORS.get(cat, "#444")}"><span class="dot"></span>{esc(cat)}</div>'
                            f'<div class="conf">{conf:.0%} confidence</div>{bars}</div>'
                            f'<div class="panel"><h3>How we read your search</h3>{toks}'
                            f'<div class="conf" style="margin-top:.5rem">Key terms after cleaning and expanding your words.</div></div>',
                            unsafe_allow_html=True)

# ---------------- browse ----------------
with tab_b:
    sub = st.selectbox("Subject", CATEGORIES)
    books = [r for r in system.by_cat[sub]]
    st.markdown(f'<div class="sec serif">{esc(sub)} · {len(books)} books</div>', unsafe_allow_html=True)
    for i, r in enumerate(sorted(books, key=lambda x: x[0])[:25]):
        card(r, None, "b", i)
    if len(books) > 25:
        st.caption(f"Showing 25 of {len(books)}. Use search to find a specific title.")

# ---------------- reading list ----------------
with tab_l:
    if not ss.saved:
        st.markdown('<div class="empty"><b>Your reading list is empty</b>Save books from your search results and they will appear here.</div>',
                    unsafe_allow_html=True)
    else:
        for i, (bid, rec) in enumerate(list(ss.saved.items())):
            card(rec, None, "l", i)
        txt = "\n".join(f"- {r[0]} ({r[1]}) [{r[2]}]" for r in ss.saved.values())
        st.download_button("Download reading list", txt, file_name="reading_list.txt")

# ---------------- model insights ----------------
with tab_m:
    best = EVAL[f"{model} + BM25 (hybrid)"]
    st.markdown('<div class="sec serif">Search quality on unseen queries</div>', unsafe_allow_html=True)
    st.caption(f"Measured on {len(system.yte)} held-out queries the model never trained on. Showing: {model} + BM25.")
    m = st.columns(4)
    for c, (k, l) in zip(m, [("accuracy", "Accuracy"), ("precision", "Precision"), ("recall", "Recall"), ("f1", "F1-score")]):
        c.markdown(f'<div class="stat"><div class="v">{best[k]:.1%}</div><div class="l">{l}</div></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec serif">Compare methods</div>', unsafe_allow_html=True)
    df = pd.DataFrame({k: {x: v[x] for x in ["accuracy", "precision", "recall", "f1"]} for k, v in EVAL.items()}).T
    df.columns = ["Accuracy", "Precision", "Recall", "F1-score"]
    st.dataframe(df.style.format("{:.1%}"), width="stretch")
    with st.expander("Per-subject report"):
        pick = st.selectbox("Method", list(EVAL), index=list(EVAL).index(f"{model} + BM25 (hybrid)"))
        st.code(EVAL[pick]["report"])
    st.markdown('<div class="sec serif">The pipeline</div>', unsafe_allow_html=True)
    st.write("Your words are cleaned (tokenising, stop-word removal, lemmatising, stemming) and turned into TF-IDF features. "
             "An SVM or Naive Bayes classifier predicts the subject, BM25 evidence from the whole catalogue refines it, "
             "and books in that subject are ranked with BM25.")
