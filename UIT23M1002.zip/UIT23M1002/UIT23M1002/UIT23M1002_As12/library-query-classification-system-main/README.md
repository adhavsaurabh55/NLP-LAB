# 📚 Central Library — Smart Query Classification & Retrieval System

An intelligent, hybrid Natural Language Processing (NLP) and Information Retrieval (IR) system designed to classify unstructured natural language user queries into 10 academic domains and retrieve highly relevant books, even when the exact book title is unknown.

Built for **Central Library · Sanjivani College of Engineering, Kopargaon** (Group A1-01).

---

## 🌟 Key Features & Highlights

- **Hybrid Classification Architecture:** Combines supervised machine learning (**Linear Support Vector Machine (LinearSVC)** & **Multinomial Naive Bayes**) trained on TF-IDF n-grams with unsupervised **BM25Okapi** catalog evidence.
- **Out-of-Vocabulary (OOV) Resilience:** Query synonym expansion and global BM25 evidence blending ensure queries containing unseen terms (e.g., *"backend"*, *"fullstack"*, *"coder"*) are correctly routed.
- **Low-Confidence Warning & Fallback:** Evaluates classification confidence. If top confidence drops below **45%**, the system warns the user and provides runner-up subject recommendations.
- **Category-Filtered BM25 Ranking:** Once a subject category is identified, books in that category are ranked dynamically using **BM25Okapi** scoring against titles and keywords.
- **Interactive Web Interface (Streamlit):**
  - Instant query search with confidence distribution meters.
  - Interactive book preview cards with relevance match percentages.
  - Reading list builder with `.txt` export capability.
  - Subject catalog browser.
  - Live model performance comparison and classification reports.
- **24/7 Cloud Ready:** Configured for one-click deployment to **Streamlit Community Cloud** or local execution.

---

## 🏗️ System Architecture & Data Flow

```mermaid
flowchart TD
    A[User Natural Language Query] --> B[NLP Preprocessing Pipeline]
    
    subgraph Preprocessing ["NLP Preprocessing Pipeline"]
        B1[Regex Tokenization] --> B2[NLTK Stop-word Removal]
        B2 --> B3[WordNet Lemmatization]
        B3 --> B4[Porter Stemming]
        B4 --> B5[Synonym Expansion Map]
    end
    
    B --> Preprocessing
    Preprocessing --> C1[TF-IDF Vectorizer 1,2-grams]
    Preprocessing --> C2[Global Catalog BM25 Evidence]
    
    C1 --> D1[LinearSVC / Naive Bayes Classifier]
    D1 --> E1[ML Class Probabilities P_ML]
    C2 --> E2[BM25 Evidence Probabilities P_BM25]
    
    E1 --> F[Hybrid Blending Layer: 0.5 * P_ML + 0.5 * P_BM25]
    E2 --> F
    
    F --> G{Top Confidence < 45%?}
    G -- Yes --> H1[Flag Low Confidence & Compute Runner-Up Subject]
    G -- No --> H2[Select Top Subject Category]
    
    H1 --> I[Intra-Category BM25 Okapi Ranking]
    H2 --> I
    
    I --> J[Ranked Book Cards & Streamlit Web UI]
```

---

## 🔄 Project Pipeline Explained

1. **Text Preprocessing & Normalization:**
   - **Tokenization:** Extract alphanumeric words, convert to lowercase.
   - **Stop-word Removal:** Strip common English stop words via `nltk.corpus.stopwords`.
   - **Lemmatization & Stemming:** Reduce words to base lemma (`WordNetLemmatizer`) and stem (`PorterStemmer`).
   - **Query Expansion:** Map domain terms using a domain-specific synonym map (e.g., `warming` $\rightarrow$ `climate`, `backend` $\rightarrow$ `server`, `database`, `api`).

2. **Feature Extraction & Machine Learning:**
   - **TF-IDF Vectorization:** Convert normalized queries into term frequency-inverse document frequency features with unigram and bigram ranges (`ngram_range=(1, 2)`).
   - **Classifiers:** 
     - `LinearSVC`: Linear Support Vector Classifier with margin decision function converted to soft probabilities via Softmax.
     - `MultinomialNB`: Naive Bayes classifier with Laplace smoothing (`alpha=0.5`).

3. **Hybrid BM25 Evidence Blending:**
   - To handle unseen out-of-vocabulary query words, a global `BM25Okapi` index over all catalog records calculates catalog-wide evidence scores:
     $$\text{Hybrid Score}(c) = 0.5 \cdot P_{\text{ML}}(c) + 0.5 \cdot P_{\text{BM25}}(c)$$

4. **Subject-Filtered Retrieval:**
   - Evaluates intra-category document relevance using BM25 scoring over book titles and descriptive keywords.

---

## 📊 Dataset Specifications

The dataset spans **10 core academic disciplines** curated for engineering and higher education libraries:

| Subject Category | Catalog Books ($\ge 50$) | Benchmark Queries ($\ge 50$) |
| :--- | :---: | :---: |
| **Computer Science & IT** | 52 | 51 |
| **Electrical & Electronics Engineering** | 52 | 50 |
| **Mechanical & Civil Engineering** | 52 | 50 |
| **Mathematics & Statistics** | 52 | 50 |
| **Physics** | 52 | 50 |
| **Chemistry** | 52 | 50 |
| **Biology & Medicine** | 52 | 50 |
| **Agriculture & Environment** | 52 | 50 |
| **Economics & Business** | 52 | 50 |
| **Humanities & Social Sciences** | 52 | 50 |
| **TOTAL** | **520 Books** | **501 Labelled Queries** |

> **Dataset Integrity:** Verified using automated assertions (`python data.py`) ensuring minimum threshold counts per category and valid line schema parsing (`Title|Author|Keywords`).

---

## 📈 Model Performance & Evaluation

Models are evaluated on a **75% / 25% stratified train-test split** using held-out queries never seen during training:

| Model Architecture | Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) |
| :--- | :---: | :---: | :---: | :---: |
| **LinearSVC** | ~92.8% | ~93.5% | ~92.8% | ~92.9% |
| **Multinomial Naive Bayes** | ~90.4% | ~91.2% | ~90.4% | ~90.5% |
| **LinearSVC + BM25 (Hybrid)** | **~96.0%** | **~96.5%** | **~96.0%** | **~96.1%** |
| **Naive Bayes + BM25 (Hybrid)** | ~94.4% | ~95.0% | ~94.4% | ~94.5% |

---

## 📁 Repository Structure

```
library-query-classification-system/
├── app.py                # Main Streamlit Web Application & UI Layout
├── nlp_core.py           # NLP Pipeline (Preprocessing, Machine Learning, Hybrid BM25)
├── data.py               # Dataset Loader & Validation Script
├── catalog.txt           # Raw Dataset: 520 Catalog Books organized by category
├── queries.txt           # Raw Dataset: 501 Ground-Truth Labelled Queries
├── requirements.txt      # Python Dependencies
├── .streamlit/
│   └── config.toml       # Streamlit Theme & Configuration
├── .gitignore            # Git exclusion rules
└── README.md             # System Documentation & Guide
```

---

## 🛠️ Step-by-Step Installation & Execution Guide

### Prerequisites
- Python 3.9+ installed on your system.
- Git installed.

### 1. Clone the Repository
```bash
git clone https://github.com/Saish-aher-28/library-query-classification-system.git
cd library-query-classification-system
```

### 2. Set Up a Virtual Environment (Recommended)
- **Windows (PowerShell / CMD):**
  ```powershell
  python -m venv venv
  .\venv\Scripts\activate
  ```
- **macOS / Linux:**
  ```bash
  python3 -m venv venv
  source venv/bin/activate
  ```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Verify Dataset Counts & Integrity
```bash
python data.py
```
*Output should report `OK: >=10 categories, >=50 books and >=50 queries per category`.*

### 5. Run Core Model Pipeline & Evaluation
```bash
python nlp_core.py
```
*Runs the evaluation suite on 25% held-out test queries and prints model metrics and sample inference tests.*

### 6. Launch the Streamlit Web Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## ☁️ Deployment Guide (Streamlit Community Cloud)

To make this web application available publicly for anyone:

1. Fork or push this repository to your **GitHub** account.
2. Visit **[share.streamlit.io](https://share.streamlit.io)** and log in with GitHub.
3. Click **New app**, select your repository `Saish-aher-28/library-query-classification-system`, set branch to `main`, and main file to `app.py`.
4. Click **Deploy!**

---

## 👥 Authors & Academic Context

- **Institution:** Sanjivani College of Engineering, Kopargaon
- **Department:** Central Library / Computer Engineering & NLP Lab
- **Group:** A1-01

---

## 📜 License

Distributed under the MIT License. See `LICENSE` for more information.
