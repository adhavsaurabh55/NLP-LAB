"""Loads the dataset from dataset/catalog.txt and dataset/queries.txt.
catalog.txt line format : Title|Author|keywords        (under a '## Category' header)
queries.txt line format : one user query per line      (under a '## Category' header)
"""
import os
_HERE = os.path.dirname(os.path.abspath(__file__))

def _find(name):
    # Works whether the files are in ./dataset/ or directly next to data.py
    for folder in (os.path.join(_HERE, "dataset"), _HERE):
        p = os.path.join(folder, name)
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"{name} not found. Put catalog.txt and queries.txt "
                            f"in {_HERE} or in {os.path.join(_HERE, 'dataset')}")

def _read(name):
    cur, out = None, {}
    with open(_find(name), encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("## "):
                cur = line[3:].strip(); out[cur] = []
            elif line:
                out[cur].append(line)
    return out

_cat = _read("catalog.txt")
CATALOG = [(t, a, cat, d) for cat, lines in _cat.items()
           for t, a, d in (l.split("|") for l in lines)]
QUERIES = _read("queries.txt")
CATEGORIES = list(_cat)

if __name__ == "__main__":
    print(f"{'Category':40s}{'Books':>7}{'Queries':>9}")
    for c in CATEGORIES:
        print(f"{c:40s}{len(_cat[c]):>7}{len(QUERIES[c]):>9}")
    print(f"{'TOTAL':40s}{len(CATALOG):>7}{sum(map(len, QUERIES.values())):>9}")
    assert all(len(_cat[c]) >= 50 and len(QUERIES[c]) >= 50 for c in CATEGORIES) and len(CATEGORIES) >= 10
    assert all(len(set(l.split('|')[0:2])) and l.count('|') == 2 for v in _cat.values() for l in v)
    print("OK: >=10 categories, >=50 books and >=50 queries per category")
